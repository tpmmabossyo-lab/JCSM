VM — Site de prière du chapelet

Pour publier avec GitHub Pages :
1. Crée un dépôt GitHub nommé VM.
2. Décompresse ce ZIP sur ton ordinateur.
3. Envoie le fichier index.html à la racine du dépôt.
4. Clique sur Add file / Commit changes pour enregistrer.
5. Dans Settings > Pages, choisis Deploy from a branch, la branche main et / (root), puis Save.
6. Attends le déploiement et ouvre l'adresse affichée dans Settings > Pages.

La récitation vocale utilise les voix françaises disponibles dans le navigateur. Garde la page ouverte pendant la récitation.
